#include "restSimulator.h"


	void hvac_simulator::updateMqttMessage_req(std::string Number,std::string Value){
		mqttMessage.at("1").at("req")="NA";
		mqttMessage.at("2").at("req")="NA";
		mqttMessage.at("3").at("req")="NA";
		mqttMessage.at("4").at("req")="NA";
		mqttMessage.at("5").at("req")="NA";
		mqttMessage.at(Number).at("req")=Value;
	}

	void hvac_simulator::temperatureChangeFn(){

		printf("temperatureChangeFn\n");

		while(true){
			std::this_thread::sleep_for(std::chrono::seconds(1));
			{
				std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
				if(temperatureSetPoint.load()>hvac_cache.currentTemperature){
					{
						hvac_cache.currentTemperature+=1;
					}
				}
				else if(temperatureSetPoint.load()<hvac_cache.currentTemperature){
					{
						hvac_cache.currentTemperature-=1;
					}
				}
				else if(temperatureSetPoint.load()==hvac_cache.currentTemperature){
					break;
				}

				updateMqttMessage_req("1","TEMPERATURE");

				mqttMessage.at("1").at("hvacTemperatureObj").at("temp")=std::to_string(hvac_cache.currentTemperature);
				mqttMessage.at("1").at("hvacTemperatureObj").at("zone")=hvac_cache.zone;
					
				//printf("currentTemperature=%d\n",hvac_cache.currentTemperature);
				//std::cout<<"autoAcStatus"<<hvac_cache.autoAcStatus;
				//std::cout<<"defoggerStatus"<<hvac_cache.defoggerStatus;

				//temperature_var=std::to_string(hvac_cache.currentTemperature);
			}
			/* restApplication_cbk_HVAC_MQTT_CURRENT_STATUS(mqttMessage);*/
			/* restApplication_cbk_HVACRESPONSE(mqttMessage); */
			if(functionObj1!=nullptr) functionObj1(mqttMessage);
			if(functionObj2!=nullptr) functionObj2(mqttMessage);
		}
		this->isTemperatureThreadRunning=0;
	}

	/********************************************* make all managers reentrant ***************************************************/

	void hvac_simulator::temperatureManager(nlohmann::json obj){

		uint8_t setPoint;
		{
			std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
			hvac_cache.zone=obj.at("zone");
			setPoint=stoi(std::string(obj.at("temp")));

			if(setPoint==temperatureSetPoint.load()) return;
			else{
				temperatureSetPoint.store(setPoint);
				if(this->isTemperatureThreadRunning==0){
					this->isTemperatureThreadRunning=1;
					std::thread t(&hvac_simulator::temperatureChangeFn,this);
					t.detach();
				}
			}
		}
	}

	void hvac_simulator::autoacManager(nlohmann::json obj){

		std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
		hvac_cache.autoAcStatus=obj.at("status");
	}

	void hvac_simulator::defoggerManager(nlohmann::json obj){

		std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
		hvac_cache.defoggerStatus=obj.at("status");
	}

	void hvac_simulator::climateFlowControlManager(nlohmann::json obj){

		std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
		hvac_cache.climateFlowControlObj=obj.at("enum");
	}

	void hvac_simulator::fanSpeedManager(nlohmann::json obj){

		std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
		hvac_cache.fanSpeedObj=obj.at("enum");
	}

	void hvac_simulator::TemperatureManager_MQTT(nlohmann::json obj){

		temperatureManager(obj);
	}

	void hvac_simulator::AutoacManager_MQTT(nlohmann::json obj){

		std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
		hvac_cache.autoAcStatus=obj.at("status");
	}

	void hvac_simulator::DefoggerManager_MQTT(nlohmann::json obj){

		std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
		hvac_cache.defoggerStatus=obj.at("status");
	}

	void hvac_simulator::ClimateFlowControlManager_MQTT(nlohmann::json obj){

		std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
		hvac_cache.climateFlowControlObj=obj.at("enum");
	}

	void hvac_simulator::FanSpeedManager_MQTT(nlohmann::json obj){
		
		std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
		hvac_cache.fanSpeedObj=obj.at("enum");
	}

	void hvac_simulator::set_RestApplicationCbk_HVAC_MQTT_CURRENT_STATUS(std::function<void (nlohmann::json)> argFunctionObj){
		functionObj2=argFunctionObj;
	}

	void hvac_simulator::set_RestApplicationCbk_HVACRESPONSE(std::function<void (nlohmann::json)> argFunctionObj){
		functionObj1=argFunctionObj;
	}

	void hvac_simulator::initialize_cache(hvacStateMachine* hvacCachePtr){

		std::ifstream inStream;
		inStream.open("default.json");
		std::stringstream ssBuffer;
		ssBuffer<<inStream.rdbuf();
		nlohmann::json temporaryJsonHolder=nlohmann::json::parse(ssBuffer.str());
		hvacCachePtr->currentTemperature=temporaryJsonHolder["currentTemperature"];
		hvacCachePtr->zone=temporaryJsonHolder["zone"];//all
		hvacCachePtr->autoAcStatus=temporaryJsonHolder["autoAcStatus"];//false;
		hvacCachePtr->defoggerStatus=temporaryJsonHolder["defoggerStatus"]; //false;
		hvacCachePtr->climateFlowControlObj=temporaryJsonHolder["climateFlowControlObj"];
		hvacCachePtr->fanSpeedObj=temporaryJsonHolder["fanSpeedObj"];

		//std::string climateFlowControlObj_json=temporaryJsonHolder["climateFlowControlObj"];
		//hvacCachePtr->climateFlowControlObj=(climateFlowControlObj_json=="low") ? hvacDdsObj::hvacClimateFlowControl::low : hvacDdsObj::hvacClimateFlowControl::high;
		//std::string fanSpeedObj_json=temporaryJsonHolder["fanSpeedObj"];

		//if(fanSpeedObj_json=="FAN_SPEED_1") hvacCachePtr->fanSpeedObj=hvacDdsObj::hvacFanSpeed::FAN_SPEED_1;
		//if(fanSpeedObj_json=="FAN_SPEED_2") hvacCachePtr->fanSpeedObj=hvacDdsObj::hvacFanSpeed::FAN_SPEED_2;
		//if(fanSpeedObj_json=="FAN_SPEED_3") hvacCachePtr->fanSpeedObj=hvacDdsObj::hvacFanSpeed::FAN_SPEED_3;
			
	}

void hvac_simulator::HVAC_MQTT_SET_STATUS_Listener(nlohmann::json obj){

printf("\n HVACWRITE_Listener reached \n");

	nlohmann::json HVACRESPONSE_jsonObj=						      {{"1",{
									                                        	{"messageId","message_temperature"},
									                                        	{"req","TEMPERATURE"},
									                                        	{"hvacTemperatureObj",{
									                                            	                    {"temp","17"},{"zone","all"}
									                                                	              }
									                                        	}
									                                       	}
									                                   },
									                                   {"2",{
									                                        	{"messageId","message_autoac"},
									                                        	{"req","AUTOAC"},
									                                        	{"hvacAutoAC",{
									                                        					{"status","true"}
									                                        				  }
									                                        	} 
									                                    	}
									                                    },
									                                   {"3",{
									                                        	{"messageId","message_defogger"},
									                                        	{"req","DEFOGGER"},
									                                        	{"hvacDefogger",{
									                                        						{"status","true"}
									                                        					}
									                                        	}
									                                    	}
									                                    },
									                                   {"4",{
									                                        	{"messageId","message_climate_flow_control"},
									                                        	{"req","CLIMATE_FLOW_CONTROL"}, 
									                                        	{"hvacClimateFlowControl",{
									                                        								{"enum","low"}
									                                        							  }
									                                        	}
									                                    	}
									                                    },
									                                   {"5",{
									                                        	{"messageId","message_fan_speed"},
									                                        	{"req","FAN_SPEED"},
									                                        	{"hvacFanSpeed",{
									                                        						{"enum","FAN_SPEED_1"}
									                                        					}
									                                        	}
									                                    	}
									                                	}};

    if(obj["1"]["req"]=="NA") HVACRESPONSE_jsonObj.at("1").at("req")="NA";
	else{
		TemperatureManager_MQTT(obj.at("1").at("hvacTemperatureObj"));
		std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
		HVACRESPONSE_jsonObj.at("1").at("hvacTemperatureObj").at("zone")=hvac_cache.zone;
		HVACRESPONSE_jsonObj.at("1").at("hvacTemperatureObj").at("temp")=std::to_string(hvac_cache.currentTemperature);
	}

	if(obj["2"]["req"]=="NA") HVACRESPONSE_jsonObj.at("2").at("req")="NA";
	else{
		AutoacManager_MQTT(obj.at("2").at("hvacAutoAC"));
		std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
		HVACRESPONSE_jsonObj.at("2").at("hvacAutoAC").at("status")=std::to_string(hvac_cache.autoAcStatus);
	}

	if(obj["3"]["req"]=="NA") HVACRESPONSE_jsonObj.at("3").at("req")="NA";
	else{
		DefoggerManager_MQTT(obj.at("3").at("hvacDefogger"));
		std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
		HVACRESPONSE_jsonObj.at("3").at("hvacDefogger").at("status")=std::to_string(hvac_cache.defoggerStatus);
	} 
	
	if(obj["4"]["req"]=="NA") HVACRESPONSE_jsonObj.at("4").at("req")="NA";
	else{
		ClimateFlowControlManager_MQTT(obj.at("4").at("hvacClimateFlowControl"));
		std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
		HVACRESPONSE_jsonObj.at("4").at("hvacClimateFlowControl").at("enum")=hvac_cache.climateFlowControlObj;
	}

	if(obj["5"]["req"]=="NA") HVACRESPONSE_jsonObj.at("5").at("req")="NA";
	else{
		FanSpeedManager_MQTT(obj.at("5").at("hvacFanSpeed"));
		std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
		HVACRESPONSE_jsonObj.at("5").at("hvacFanSpeed").at("enum")=hvac_cache.fanSpeedObj;
	} 
	 
	/* restApplication_cbk_HVACRESPONSE(HVACRESPONSE_jsonObj);*/
	if(functionObj1!=nullptr) functionObj1(HVACRESPONSE_jsonObj);
}


void hvac_simulator::HVACWRITE_Listener(nlohmann::json obj){

printf("\n HVACWRITE_Listener reached \n");

	nlohmann::json HVAC_MQTT_CURRENT_STATUS_jsonObj=						   {{"1",{
									                                        	{"messageId","message_temperature"},
									                                        	{"req","TEMPERATURE"},
									                                        	{"hvacTemperatureObj",{
									                                            	                    {"temp","17"},{"zone","all"}
									                                                	              }
									                                        	}
									                                       	}
									                                   },
									                                   {"2",{
									                                        	{"messageId","message_autoac"},
									                                        	{"req","AUTOAC"},
									                                        	{"hvacAutoAC",{
									                                        					{"status","true"}
									                                        				  }
									                                        	} 
									                                    	}
									                                    },
									                                   {"3",{
									                                        	{"messageId","message_defogger"},
									                                        	{"req","DEFOGGER"},
									                                        	{"hvacDefogger",{
									                                        						{"status","true"}
									                                        					}
									                                        	}
									                                    	}
									                                    },
									                                   {"4",{
									                                        	{"messageId","message_climate_flow_control"},
									                                        	{"req","CLIMATE_FLOW_CONTROL"}, 
									                                        	{"hvacClimateFlowControl",{
									                                        								{"enum","low"}
									                                        							  }
									                                        	}
									                                    	}
									                                    },
									                                   {"5",{
									                                        	{"messageId","message_fan_speed"},
									                                        	{"req","FAN_SPEED"},
									                                        	{"hvacFanSpeed",{
									                                        						{"enum","FAN_SPEED_1"}
									                                        					}
									                                        	}
									                                    	}
									                                	}};

	if(obj["1"]["req"]=="NA") HVAC_MQTT_CURRENT_STATUS_jsonObj.at("1").at("req")="NA";
	else{
		temperatureManager(obj.at("1").at("hvacTemperatureObj"));
		std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
		HVAC_MQTT_CURRENT_STATUS_jsonObj.at("1").at("hvacTemperatureObj").at("zone")=hvac_cache.zone;
		HVAC_MQTT_CURRENT_STATUS_jsonObj.at("1").at("hvacTemperatureObj").at("temp")=std::to_string(hvac_cache.currentTemperature);
	}

	if(obj["2"]["req"]=="NA") HVAC_MQTT_CURRENT_STATUS_jsonObj.at("2").at("req")="NA";
	else{
		autoacManager(obj.at("2").at("hvacAutoAC"));
		std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
		HVAC_MQTT_CURRENT_STATUS_jsonObj.at("2").at("hvacAutoAC").at("status")=std::to_string(hvac_cache.autoAcStatus);
	}

	if(obj["3"]["req"]=="NA") HVAC_MQTT_CURRENT_STATUS_jsonObj.at("3").at("req")="NA";
	else{
		defoggerManager(obj.at("3").at("hvacDefogger"));
		std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
		HVAC_MQTT_CURRENT_STATUS_jsonObj.at("3").at("hvacDefogger").at("status")=std::to_string(hvac_cache.defoggerStatus);
	} 
	
	if(obj["4"]["req"]=="NA") HVAC_MQTT_CURRENT_STATUS_jsonObj.at("4").at("req")="NA";
	else{
		climateFlowControlManager(obj.at("4").at("hvacClimateFlowControl"));
		std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
		HVAC_MQTT_CURRENT_STATUS_jsonObj.at("4").at("hvacClimateFlowControl").at("enum")=hvac_cache.climateFlowControlObj;
	}

	if(obj["5"]["req"]=="NA") HVAC_MQTT_CURRENT_STATUS_jsonObj.at("5").at("req")="NA";
	else{
		fanSpeedManager(obj.at("5").at("hvacFanSpeed"));
		std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
		HVAC_MQTT_CURRENT_STATUS_jsonObj.at("5").at("hvacFanSpeed").at("enum")=hvac_cache.fanSpeedObj;
	} 
	 
	/* restApplication_cbk_HVAC_MQTT_CURRENT_STATUS(HVAC_MQTT_CURRENT_STATUS_jsonObj);*/
	if(functionObj2!=nullptr) functionObj2(HVAC_MQTT_CURRENT_STATUS_jsonObj);	
}

void hvac_simulator::HVACREAD_Listener(nlohmann::json obj){

	printf("\n HVACREAD_Listener reached \n");

	nlohmann::json HVACRESPONSE_jsonObj=							  {{"1",{
									                                        	{"messageId","message_temperature"},
									                                        	{"req","TEMPERATURE"},
									                                        	{"hvacTemperatureObj",{
									                                            	                    {"temp","17"},{"zone","all"}
									                                                	              }
									                                        	}
									                                       	}
									                                   },
									                                   {"2",{
									                                        	{"messageId","message_autoac"},
									                                        	{"req","AUTOAC"},
									                                        	{"hvacAutoAC",{
									                                        					{"status","true"}
									                                        				  }
									                                        	} 
									                                    	}
									                                    },
									                                   {"3",{
									                                        	{"messageId","message_defogger"},
									                                        	{"req","DEFOGGER"},
									                                        	{"hvacDefogger",{
									                                        						{"status","true"}
									                                        					}
									                                        	}
									                                    	}
									                                    },
									                                   {"4",{
									                                        	{"messageId","message_climate_flow_control"},
									                                        	{"req","CLIMATE_FLOW_CONTROL"}, 
									                                        	{"hvacClimateFlowControl",{
									                                        								{"enum","low"}
									                                        							  }
									                                        	}
									                                    	}
									                                    },
									                                   {"5",{
									                                        	{"messageId","message_fan_speed"},
									                                        	{"req","FAN_SPEED"},
									                                        	{"hvacFanSpeed",{
									                                        						{"enum","FAN_SPEED_1"}
									                                        					}
									                                        	}
									                                    	}
									                                	}};

	if(obj["1"]["req"]=="NA") HVACRESPONSE_jsonObj.at("1").at("req")="NA";
	else{
		std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
		HVACRESPONSE_jsonObj.at("1").at("hvacTemperatureObj").at("zone")=hvac_cache.zone;
		HVACRESPONSE_jsonObj.at("1").at("hvacTemperatureObj").at("temp")=std::to_string(hvac_cache.currentTemperature);
	}

	if(obj["2"]["req"]=="NA") HVACRESPONSE_jsonObj.at("2").at("req")="NA";
	else{
		std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
		HVACRESPONSE_jsonObj.at("2").at("hvacAutoAC").at("status")=std::to_string(hvac_cache.autoAcStatus);
	}

	if(obj["3"]["req"]=="NA") HVACRESPONSE_jsonObj.at("3").at("req")="NA";
	else{
		std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
		HVACRESPONSE_jsonObj.at("3").at("hvacDefogger").at("status")=std::to_string(hvac_cache.defoggerStatus);
	}

	if(obj["4"]["req"]=="NA") HVACRESPONSE_jsonObj.at("4").at("req")="NA";
	else{
		std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
		HVACRESPONSE_jsonObj.at("4").at("hvacClimateFlowControl").at("enum")=hvac_cache.climateFlowControlObj;
	}

	if(obj["5"]["req"]=="NA") HVACRESPONSE_jsonObj.at("5").at("req")="NA";
	else{
		std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
		HVACRESPONSE_jsonObj.at("5").at("hvacFanSpeed").at("enum")=hvac_cache.fanSpeedObj;
	}

	/*restApplication_cbk(HVACRESPONSE_jsonObj)*/
	if(functionObj1!=nullptr) functionObj1(HVACRESPONSE_jsonObj);
}

	hvac_simulator::hvac_simulator(std::function<void (nlohmann::json)> functionObj1, std::function<void (nlohmann::json)> functionObj2) : 
													mqttMessage(      {{"1",{
									                                        	{"messageId","message_temperature"},
									                                        	{"req","TEMPERATURE"},
									                                        	{"hvacTemperatureObj",{
									                                            	                    {"temp","17"},{"zone","all"}
									                                                	              }
									                                        	}
									                                       	}
									                                   },
									                                   {"2",{
									                                        	{"messageId","message_autoac"},
									                                        	{"req","AUTOAC"},
									                                        	{"hvacAutoAC",{
									                                        					{"status","true"}
									                                        				  }
									                                        	} 
									                                    	}
									                                    },
									                                   {"3",{
									                                        	{"messageId","message_defogger"},
									                                        	{"req","DEFOGGER"},
									                                        	{"hvacDefogger",{
									                                        						{"status","true"}
									                                        					}
									                                        	}
									                                    	}
									                                    },
									                                   {"4",{
									                                        	{"messageId","message_climate_flow_control"},
									                                        	{"req","CLIMATE_FLOW_CONTROL"}, 
									                                        	{"hvacClimateFlowControl",{
									                                        								{"enum","low"}
									                                        							  }
									                                        	}
									                                    	}
									                                    },
									                                   {"5",{
									                                        	{"messageId","message_fan_speed"},
									                                        	{"req","FAN_SPEED"},
									                                        	{"hvacFanSpeed",{
									                                        						{"enum","FAN_SPEED_1"}
									                                        					}
									                                        	}
									                                    	}
									                                	}}
																){
  		
  		initialize_cache(&hvac_cache);
  		this->isTemperatureThreadRunning=0;
  		set_RestApplicationCbk_HVACRESPONSE(functionObj1);
  		set_RestApplicationCbk_HVAC_MQTT_CURRENT_STATUS(functionObj2);
	}

	hvac_simulator::~hvac_simulator(){}