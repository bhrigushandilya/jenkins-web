#include "restApplication.h"

hvac_simulator *simulatorObjPtr;

void getRequest_HVACREAD(http_request getReqObj){

	printf("\n getRequest_HVACREAD arrived \n");
	//pplx::task<web::json::value> tempTask=getReqObj.extract_json();
	//tempTask.wait();
	//web::json::value rcvData=tempTask.get();
	
/*
	msg_HVACREAD_template.at("1").at("messageId")=rcvData.at("1").at("messageId").as_string();
	msg_HVACREAD_template.at("1").at("req")=rcvData.at("1").at("req").as_string();
	msg_HVACREAD_template.at("1").at("hvacTemperatureObj").at("temp")=rcvData.at("1").at("hvacTemperatureObj").at("temp").as_string();
	msg_HVACREAD_template.at("1").at("hvacTemperatureObj").at("zone")=rcvData.at("1").at("hvacTemperatureObj").at("zone").as_string();

	msg_HVACREAD_template.at("2").at("messageId")=rcvData.at("2").at("messageId").as_string();
	msg_HVACREAD_template.at("2").at("req")=rcvData.at("2").at("req").as_string();
	msg_HVACREAD_template.at("2").at("hvacAutoAC").at("status")=rcvData.at("2").at("hvacAutoAC").as_string();

	msg_HVACREAD_template.at("3").at("messageId")=rcvData.at("3").at("messageId").as_string();
	msg_HVACREAD_template.at("3").at("req")=rcvData.at("3").at("req").as_string();
	msg_HVACREAD_template.at("3").at("hvacDefogger").at("status")=rcvData.at("3").at("hvacDefogger").at("status").as_string();	

	msg_HVACREAD_template.at("4").at("messageId")=rcvData.at("4").at("messageId").as_string();
	msg_HVACREAD_template.at("4").at("req")=rcvData.at("4").at("req").as_string();
	msg_HVACREAD_template.at("4").at("hvacClimateFlowControl").at("enum")=rcvData.at("4").at("hvacClimateFlowControl").at("enum").as_string();

	msg_HVACREAD_template.at("5").at("messageId")=rcvData.at("5").at("messageId").as_string();
	msg_HVACREAD_template.at("5").at("req")=rcvData.at("5").at("req").as_string();
	msg_HVACREAD_template.at("5").at("hvacFanSpeed").at("enum")=rcvData.at("5").at("hvacFanSpeed").at("enum").as_string();
*/
	simulatorObjPtr->HVACREAD_Listener(msg_HVACREAD_template);
}

void postRequest_HVACWRITE(http_request postReqObj){

	printf("\n postRequest_HVACWRITE arrived \n");
	pplx::task<web::json::value> tempTask=postReqObj.extract_json();
	tempTask.wait();
	web::json::value rcvData=tempTask.get();
	printf("\n size=%s \n",&rcvData.at("1").at("messageId").as_string()[0]);
	//printf("\n rcv data=%s \n",&rcvData.at("1").at("messageId").as_string()[0]);
	printf("\n template data=%s \n",&msg_HVACWRITE_template.at("1").at("messageId").dump()[0]);
	
	msg_HVACWRITE_template.at("1").at("messageId")=&rcvData.at("1").at("messageId").as_string()[0];
	msg_HVACWRITE_template.at("1").at("req")=&rcvData.at("1").at("req").as_string()[0];
	msg_HVACWRITE_template.at("1").at("hvacTemperatureObj").at("temp")=&rcvData.at("1").at("hvacTemperatureObj").at("temp").as_string()[0];
	msg_HVACWRITE_template.at("1").at("hvacTemperatureObj").at("zone")=&rcvData.at("1").at("hvacTemperatureObj").at("zone").as_string()[0];

	msg_HVACWRITE_template.at("2").at("messageId")=&rcvData.at("2").at("messageId").as_string()[0];
	msg_HVACWRITE_template.at("2").at("req")=&rcvData.at("2").at("req").as_string()[0];
	msg_HVACWRITE_template.at("2").at("hvacAutoAC").at("status")=&rcvData.at("2").at("hvacAutoAC").at("status").as_string()[0];

	msg_HVACWRITE_template.at("3").at("messageId")=&rcvData.at("3").at("messageId").as_string()[0];
	msg_HVACWRITE_template.at("3").at("req")=&rcvData.at("3").at("req").as_string()[0];
	msg_HVACWRITE_template.at("3").at("hvacDefogger").at("status")=&rcvData.at("3").at("hvacDefogger").at("status").as_string()[0];	

	msg_HVACWRITE_template.at("4").at("messageId")=&rcvData.at("4").at("messageId").as_string()[0];
	msg_HVACWRITE_template.at("4").at("req")=&rcvData.at("4").at("req").as_string()[0];
	msg_HVACWRITE_template.at("4").at("hvacClimateFlowControl").at("enum")=&rcvData.at("4").at("hvacClimateFlowControl").at("enum").as_string()[0];

	msg_HVACWRITE_template.at("5").at("messageId")=&rcvData.at("5").at("messageId").as_string()[0];
	msg_HVACWRITE_template.at("5").at("req")=&rcvData.at("5").at("req").as_string()[0];
	msg_HVACWRITE_template.at("5").at("hvacFanSpeed").at("enum")=&rcvData.at("5").at("hvacFanSpeed").at("enum").as_string()[0];

	simulatorObjPtr->HVACWRITE_Listener(msg_HVACWRITE_template);
}

void postRequest_HVAC_MQTT_SET_STATUS(http_request postReqObj){

	printf("\n postRequest_HVAC_MQTT_SET_STATUS arrived \n");
	pplx::task<web::json::value> tempTask=postReqObj.extract_json();
	tempTask.wait();
	web::json::value rcvData=tempTask.get();

	msg_HVAC_MQTT_SET_STATUS_template.at("1").at("messageId")=&rcvData.at("1").at("messageId").as_string()[0];
	msg_HVAC_MQTT_SET_STATUS_template.at("1").at("req")=&rcvData.at("1").at("req").as_string()[0];
	msg_HVAC_MQTT_SET_STATUS_template.at("1").at("hvacTemperatureObj").at("temp")=&rcvData.at("1").at("hvacTemperatureObj").at("temp").as_string()[0];
	msg_HVAC_MQTT_SET_STATUS_template.at("1").at("hvacTemperatureObj").at("zone")=&rcvData.at("1").at("hvacTemperatureObj").at("zone").as_string()[0];

	msg_HVAC_MQTT_SET_STATUS_template.at("2").at("messageId")=&rcvData.at("2").at("messageId").as_string()[0];
	msg_HVAC_MQTT_SET_STATUS_template.at("2").at("req")=&rcvData.at("2").at("req").as_string()[0];
	msg_HVAC_MQTT_SET_STATUS_template.at("2").at("hvacAutoAC").at("status")=&rcvData.at("2").at("hvacAutoAC").at("status").as_string()[0];

	msg_HVAC_MQTT_SET_STATUS_template.at("3").at("messageId")=&rcvData.at("3").at("messageId").as_string()[0];
	msg_HVAC_MQTT_SET_STATUS_template.at("3").at("req")=&rcvData.at("3").at("req").as_string()[0];
	msg_HVAC_MQTT_SET_STATUS_template.at("3").at("hvacDefogger").at("status")=&rcvData.at("3").at("hvacDefogger").at("status").as_string()[0];	

	msg_HVAC_MQTT_SET_STATUS_template.at("4").at("messageId")=&rcvData.at("4").at("messageId").as_string()[0];
	msg_HVAC_MQTT_SET_STATUS_template.at("4").at("req")=&rcvData.at("4").at("req").as_string()[0];
	msg_HVAC_MQTT_SET_STATUS_template.at("4").at("hvacClimateFlowControl").at("enum")=&rcvData.at("4").at("hvacClimateFlowControl").at("enum").as_string()[0];

	msg_HVAC_MQTT_SET_STATUS_template.at("5").at("messageId")=&rcvData.at("5").at("messageId").as_string()[0];
	msg_HVAC_MQTT_SET_STATUS_template.at("5").at("req")=&rcvData.at("5").at("req").as_string()[0];
	msg_HVAC_MQTT_SET_STATUS_template.at("5").at("hvacFanSpeed").at("enum")=&rcvData.at("5").at("hvacFanSpeed").at("enum").as_string()[0];

	simulatorObjPtr->HVAC_MQTT_SET_STATUS_Listener(msg_HVAC_MQTT_SET_STATUS_template);
}
/*
void getRequest(http_request reqObj){
	printf("\nreceived\n");
	hvacDdsObj::hvacReadReqObj sendData;
	sendData.messageId=CORBA::string_dup("restsdk_request");
	sendData.feature=hvacDdsObj::featureType::TEMPERATURE;

	bridgeObjPtr->HVACREAD_Publish(&sendData);
	printf("\n sent data to dds \n");
}

void postRequest(http_request reqObj){
	printf("\npost received\n");
	pplx::task<value> tempTask=reqObj.extract_json();
	tempTask.wait();
	value rcvData=tempTask.get();
	float temperature=rcvData.at("temperature").as_double();
	float timestamp=rcvData.at("timestamp").as_double();
	std::string zone=rcvData.at("zone").as_string();
	float id=rcvData.at("id").as_double();

	//std::cout<<"temperature"<<temperature<<"timestamp"<<timestamp<<"zone"<<zone<<"id"<<id<<std::endl;
	hvacDdsObj::hvacWriteReqObj sendData;
	sendData.messageId=CORBA::string_dup("restsdk_request");
	sendData.req=hvacDdsObj::featureType::TEMPERATURE;
	hvacDdsObj::hvacTemperatureObj tempobj;
	tempobj.zone=CORBA::string_dup(&zone[0]);
	tempobj.temp=CORBA::string_dup(&std::to_string(temperature)[0]);
	hvacDdsObj::ListenerTypeStruct* lts = new hvacDdsObj::ListenerTypeStruct();
	lts->_d(sendData.req);
	lts->temperatureObj(tempobj);
	sendData.featureObj=*lts;
	
	bridgeObjPtr->HVACWRITE_Publish(&sendData);
	printf("\n sent data to dds \n");
}
*/

void RestApplicationCbk_HVAC_MQTT_CURRENT_STATUS(nlohmann::json msg_HVAC_MQTT_CURRENT_STATUS){

	printf("\n RestApplicationCbk_HVAC_MQTT_CURRENT_STATUS arrived \n");

	msg_HVAC_MQTT_CURRENT_STATUS_template.at("1").at("messageId")=web::json::value::parse(msg_HVAC_MQTT_CURRENT_STATUS.at("1").at("messageId").dump());
	msg_HVAC_MQTT_CURRENT_STATUS_template.at("1").at("req")=web::json::value::parse(msg_HVAC_MQTT_CURRENT_STATUS.at("1").at("req").dump());
	msg_HVAC_MQTT_CURRENT_STATUS_template.at("1").at("hvacTemperatureObj").at("temp")=web::json::value::parse(msg_HVAC_MQTT_CURRENT_STATUS.at("1").at("hvacTemperatureObj").at("temp").dump());
	msg_HVAC_MQTT_CURRENT_STATUS_template.at("1").at("hvacTemperatureObj").at("zone")=web::json::value::parse(msg_HVAC_MQTT_CURRENT_STATUS.at("1").at("hvacTemperatureObj").at("zone").dump());

	msg_HVAC_MQTT_CURRENT_STATUS_template.at("2").at("messageId")=web::json::value::parse(msg_HVAC_MQTT_CURRENT_STATUS.at("2").at("messageId").dump());
	msg_HVAC_MQTT_CURRENT_STATUS_template.at("2").at("req")=web::json::value::parse(msg_HVAC_MQTT_CURRENT_STATUS.at("2").at("req").dump());
	msg_HVAC_MQTT_CURRENT_STATUS_template.at("2").at("hvacAutoAC").at("status")=web::json::value::parse(msg_HVAC_MQTT_CURRENT_STATUS.at("2").at("hvacAutoAC").at("status").dump());

	msg_HVAC_MQTT_CURRENT_STATUS_template.at("3").at("messageId")=web::json::value::parse(msg_HVAC_MQTT_CURRENT_STATUS.at("3").at("messageId").dump());
	msg_HVAC_MQTT_CURRENT_STATUS_template.at("3").at("req")=web::json::value::parse(msg_HVAC_MQTT_CURRENT_STATUS.at("3").at("req").dump());
	msg_HVAC_MQTT_CURRENT_STATUS_template.at("3").at("hvacDefogger").at("status")=web::json::value::parse(msg_HVAC_MQTT_CURRENT_STATUS.at("3").at("hvacDefogger").at("status").dump());	

	msg_HVAC_MQTT_CURRENT_STATUS_template.at("4").at("messageId")=web::json::value::parse(msg_HVAC_MQTT_CURRENT_STATUS.at("4").at("messageId").dump());
	msg_HVAC_MQTT_CURRENT_STATUS_template.at("4").at("req")=web::json::value::parse(msg_HVAC_MQTT_CURRENT_STATUS.at("4").at("req").dump());
	msg_HVAC_MQTT_CURRENT_STATUS_template.at("4").at("hvacClimateFlowControl").at("enum")=web::json::value::parse(msg_HVAC_MQTT_CURRENT_STATUS.at("4").at("hvacClimateFlowControl").at("enum").dump());

	msg_HVAC_MQTT_CURRENT_STATUS_template.at("5").at("messageId")=web::json::value::parse(msg_HVAC_MQTT_CURRENT_STATUS.at("5").at("messageId").dump());
	msg_HVAC_MQTT_CURRENT_STATUS_template.at("5").at("req")=web::json::value::parse(msg_HVAC_MQTT_CURRENT_STATUS.at("5").at("req").dump());
	msg_HVAC_MQTT_CURRENT_STATUS_template.at("5").at("hvacFanSpeed").at("enum")=web::json::value::parse(msg_HVAC_MQTT_CURRENT_STATUS.at("5").at("hvacFanSpeed").at("enum").dump());

	uri address_HVAC_MQTT_CURRENT_STATUS("http://localhost:5000/HVAC_MQTT_CURRENT_STATUS");
	client::http_client client_HVAC_MQTT_CURRENT_STATUS(address_HVAC_MQTT_CURRENT_STATUS);
	client_HVAC_MQTT_CURRENT_STATUS.request(methods::POST,"",msg_HVAC_MQTT_CURRENT_STATUS_template).wait();

	printf("\n done \n");
}

void RestApplicationCbk_HVACRESPONSE(nlohmann::json msg_HVACRESPONSE){

	printf("\n RestApplicationCbk_HVACRESPONSE arrived \n");

	msg_HVACRESPONSE_template.at("1").at("messageId")=web::json::value::parse(msg_HVACRESPONSE.at("1").at("messageId").dump());
	msg_HVACRESPONSE_template.at("1").at("req")=web::json::value::parse(msg_HVACRESPONSE.at("1").at("req").dump());
	msg_HVACRESPONSE_template.at("1").at("hvacTemperatureObj").at("temp")=web::json::value::parse(msg_HVACRESPONSE.at("1").at("hvacTemperatureObj").at("temp").dump());
	msg_HVACRESPONSE_template.at("1").at("hvacTemperatureObj").at("zone")=web::json::value::parse(msg_HVACRESPONSE.at("1").at("hvacTemperatureObj").at("zone").dump());

	msg_HVACRESPONSE_template.at("2").at("messageId")=web::json::value::parse(msg_HVACRESPONSE.at("2").at("messageId").dump());
	msg_HVACRESPONSE_template.at("2").at("req")=web::json::value::parse(msg_HVACRESPONSE.at("2").at("req").dump());
	msg_HVACRESPONSE_template.at("2").at("hvacAutoAC").at("status")=web::json::value::parse(msg_HVACRESPONSE.at("2").at("hvacAutoAC").at("status").dump());

	msg_HVACRESPONSE_template.at("3").at("messageId")=web::json::value::parse(msg_HVACRESPONSE.at("3").at("messageId").dump());
	msg_HVACRESPONSE_template.at("3").at("req")=web::json::value::parse(msg_HVACRESPONSE.at("3").at("req").dump());
	msg_HVACRESPONSE_template.at("3").at("hvacDefogger").at("status")=web::json::value::parse(msg_HVACRESPONSE.at("3").at("hvacDefogger").at("status").dump());	

	msg_HVACRESPONSE_template.at("4").at("messageId")=web::json::value::parse(msg_HVACRESPONSE.at("4").at("messageId").dump());
	msg_HVACRESPONSE_template.at("4").at("req")=web::json::value::parse(msg_HVACRESPONSE.at("4").at("req").dump());
	msg_HVACRESPONSE_template.at("4").at("hvacClimateFlowControl").at("enum")=web::json::value::parse(msg_HVACRESPONSE.at("4").at("hvacClimateFlowControl").at("enum").dump());

	msg_HVACRESPONSE_template.at("5").at("messageId")=web::json::value::parse(msg_HVACRESPONSE.at("5").at("messageId").dump());
	msg_HVACRESPONSE_template.at("5").at("req")=web::json::value::parse(msg_HVACRESPONSE.at("5").at("req").dump());
	msg_HVACRESPONSE_template.at("5").at("hvacFanSpeed").at("enum")=web::json::value::parse(msg_HVACRESPONSE.at("5").at("hvacFanSpeed").at("enum").dump());

	uri address_HVACRESPONSE("http://localhost:5000/HVACRESPONSE");
	client::http_client client_HVACRESPONSE(address_HVACRESPONSE); 
	client_HVACRESPONSE.request(methods::POST,"",msg_HVACRESPONSE_template).wait();

	printf("\n done \n");
}

int main(int argc, char** argv){

	std::function<void (nlohmann::json)> functionObject_HVACRESPONSE=std::bind(&RestApplicationCbk_HVACRESPONSE,std::placeholders::_1);
	std::function<void (nlohmann::json)> functionObject_HVAC_MQTT_CURRENT_STATUS=std::bind(&RestApplicationCbk_HVAC_MQTT_CURRENT_STATUS,std::placeholders::_1);

	simulatorObjPtr = new hvac_simulator(functionObject_HVACRESPONSE,functionObject_HVAC_MQTT_CURRENT_STATUS);

	uri address_HVACREAD("http://localhost:5000/HVACREAD");
	uri address_HVACWRITE("http://localhost:5000/HVACWRITE");
	uri address_HVAC_MQTT_SET_STATUS("http://localhost:5000/HVAC_MQTT_SET_STATUS");

	http_listener listener_HVACREAD(address_HVACREAD);
	http_listener listener_HVACWRITE(address_HVACWRITE);
	http_listener listener_HVAC_MQTT_SET_STATUS(address_HVAC_MQTT_SET_STATUS);

	listener_HVACREAD.support("GET",&getRequest_HVACREAD);
	listener_HVACWRITE.support("POST",&postRequest_HVACWRITE);
	listener_HVAC_MQTT_SET_STATUS.support("POST",&postRequest_HVAC_MQTT_SET_STATUS);

	//pplx::task<void> openTask=listener.open();//.wait();
	//openTask.wait();
	listener_HVACREAD.open().wait();
	listener_HVACWRITE.open().wait();
	listener_HVAC_MQTT_SET_STATUS.open().wait();

	printf("\n ready \n");
	//web::json::value msg_temp=web::json::value::parse("{\"1\":{\"messageId_1\":\"message_temperature_1\",\"messageId_2\":\"message_temperature_2\"},\"2\":{\"messageId_1\":\"message_temperature_1\",\"messageId_2\":\"message_temperature_2\"}}");
	
	//printf("\n size=%s \n",&msg_HVACRESPONSE_template.at("1").at("messageId").as_string()[0]);
	while(true);
	listener_HVACREAD.close().wait();
	listener_HVACWRITE.close().wait();
	listener_HVAC_MQTT_SET_STATUS.close().wait();

	return(0);
}