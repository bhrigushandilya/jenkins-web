#include "ddsNode_hvacUI.h"
#include "ddsNode_hvacMQTT.h"
#include "chrono"
#include "thread"
#include "json.hpp"
#include "fstream"
#include <mutex>

using json = nlohmann::json;

struct hvacStateMachine{
	uint8_t currentTemperature;
	std::string zone;
	bool autoAcStatus;
	bool defoggerStatus;
	hvacDdsObj::hvacClimateFlowControl climateFlowControlObj;
	hvacDdsObj::hvacFanSpeed fanSpeedObj;
};

class hvac_simulator {
	private:

	std::atomic<uint8_t> temperatureSetPoint;
	hvacStateMachine hvac_cache;
	//ddsHVAC_SimLib* hvac_obj;
	ddsNode_hvacUI* hvacUiPtr;
	ddsNode_hvacMQTT* hvacMqttPtr;
	std::atomic<uint8_t> isTemperatureThreadRunning;
	json mqttMessage;
	hvacDdsObj::DataType jsonDDS;
	std::mutex hvacCache_lock;

	void updateMqttMessage_req(std::string Number,std::string Value){
		mqttMessage.at("1").at("req")="NA";
		mqttMessage.at("2").at("req")="NA";
		mqttMessage.at("3").at("req")="NA";
		mqttMessage.at("4").at("req")="NA";
		mqttMessage.at("5").at("req")="NA";
		mqttMessage.at(Number).at("req")=Value;
	}

	void temperatureChangeFn(){

		printf("temperatureChangeFn\n");
		hvacDdsObj::hvacListenerObj obj;
		hvacDdsObj::hvacTemperatureObj tempObj;
		hvacDdsObj::ListenerTypeStruct* lst= new hvacDdsObj::ListenerTypeStruct();
		std::string temperature_var;
		char* temporaryTemperatureVar;

		obj.messageId="temperature update";
		obj.feature=hvacDdsObj::featureType::TEMPERATURE;
		{
			std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
			tempObj.zone=CORBA::string_dup(&hvac_cache.zone[0]);
		}
		lst->_d(obj.feature);

		while(true){
			std::this_thread::sleep_for(std::chrono::seconds(1));
			{
				std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
				if(temperatureSetPoint.load()>hvac_cache.currentTemperature){
					{
						hvac_cache.currentTemperature+=1;
					}
				}
				else if(temperatureSetPoint.load()<hvac_cache.currentTemperature){
					{
						hvac_cache.currentTemperature-=1;
					}
				}
				else if(temperatureSetPoint.load()==hvac_cache.currentTemperature){
					break;
				}

				updateMqttMessage_req("1","TEMPERATURE");

				mqttMessage.at("1").at("hvacTemperatureObj").at("temp")=std::to_string(hvac_cache.currentTemperature);
				mqttMessage.at("1").at("hvacTemperatureObj").at("zone")=hvac_cache.zone;
					
				//printf("currentTemperature=%d\n",hvac_cache.currentTemperature);
				//std::cout<<"autoAcStatus"<<hvac_cache.autoAcStatus;
				//std::cout<<"defoggerStatus"<<hvac_cache.defoggerStatus;

				temperature_var=std::to_string(hvac_cache.currentTemperature);
			}

			
			temporaryTemperatureVar=CORBA::string_dup(&temperature_var[0]);
			tempObj.temp=temporaryTemperatureVar;
			lst->temperatureObj(tempObj);
			obj.featureObj=*lst;
			hvacUiPtr->HVACFn_HVACRESPONSE_Write(obj);
			//hvac_obj->HVACFnResponseWriteRequest(obj);
			jsonDDS.params=CORBA::string_dup(&mqttMessage.dump()[0]);
			hvacMqttPtr->HVACFn_HVAC_MQTT_CURRENT_STATUS_Write(jsonDDS);
			//hvac_obj->HVACFnMQTTWriteRequest(jsonDDS);
			//CORBA::string_free(temporaryTemperatureVar);

		}
		std::free(lst);
		this->isTemperatureThreadRunning=0;
	}

	/********************************************* make all managers reentrant ***************************************************/

	void temperatureManager(hvacDdsObj::hvacTemperatureObj obj){

		uint8_t setPoint=stoi(std::string(obj.temp._retn()));

		if(setPoint==temperatureSetPoint.load()) return;
		else{
			temperatureSetPoint.store(setPoint);
			if(this->isTemperatureThreadRunning==0){
				this->isTemperatureThreadRunning=1;
				std::thread t(&hvac_simulator::temperatureChangeFn,this);
				t.detach();
			}
		}
	}

	void autoacManager(hvacDdsObj::hvacAutoAC obj){

		{
			std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
			hvac_cache.autoAcStatus=obj.status;
			updateMqttMessage_req("2","AUTOAC");
			mqttMessage.at("2").at("hvacAutoAC").at("status")=((hvac_cache.autoAcStatus==true) ? "true" : "false");
		}
			
		jsonDDS.params=CORBA::string_dup(&mqttMessage.dump()[0]);
		hvacMqttPtr->HVACFn_HVAC_MQTT_CURRENT_STATUS_Write(jsonDDS);
		//hvac_obj->HVACFnMQTTWriteRequest(jsonDDS);
	}

	void defoggerManager(hvacDdsObj::hvacDefogger obj){

		{
			std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
			hvac_cache.defoggerStatus=obj.status;
			updateMqttMessage_req("3","DEFOGGER");
			mqttMessage.at("3").at("hvacDefogger").at("status")=((hvac_cache.defoggerStatus==true) ? "true" : "false");
		}
		
		jsonDDS.params=CORBA::string_dup(&mqttMessage.dump()[0]);
		hvacMqttPtr->HVACFn_HVAC_MQTT_CURRENT_STATUS_Write(jsonDDS);
		//hvac_obj->HVACFnMQTTWriteRequest(jsonDDS);
	}

	void climateFlowControlManager(hvacDdsObj::hvacClimateFlowControl obj){

		{
			std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
			hvac_cache.climateFlowControlObj=obj;
			updateMqttMessage_req("4","CLIMATE_FLOW_CONTROL");
			mqttMessage.at("4").at("hvacClimateFlowControl").at("enum")=((hvac_cache.climateFlowControlObj==hvacDdsObj::hvacClimateFlowControl::low) ? "low" : "high");
		}

		jsonDDS.params=CORBA::string_dup(&mqttMessage.dump()[0]);
		hvacMqttPtr->HVACFn_HVAC_MQTT_CURRENT_STATUS_Write(jsonDDS);
		//hvac_obj->HVACFnMQTTWriteRequest(jsonDDS);
	}

	void fanSpeedManager(hvacDdsObj::hvacFanSpeed obj){

		{
			std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
			hvac_cache.fanSpeedObj=obj;
			updateMqttMessage_req("5","FAN_SPEED");
			switch(hvac_cache.fanSpeedObj){
				case hvacDdsObj::hvacFanSpeed::FAN_SPEED_1:
					mqttMessage.at("5").at("hvacFanSpeed").at("enum")="FAN_SPEED_1";
					break;
				case hvacDdsObj::hvacFanSpeed::FAN_SPEED_2:
					mqttMessage.at("5").at("hvacFanSpeed").at("enum")="FAN_SPEED_2";
					break;
				case hvacDdsObj::hvacFanSpeed::FAN_SPEED_3:
					mqttMessage.at("5").at("hvacFanSpeed").at("enum")="FAN_SPEED_3";
					break;
			}

		}
			
		jsonDDS.params=CORBA::string_dup(&mqttMessage.dump()[0]);
		hvacMqttPtr->HVACFn_HVAC_MQTT_CURRENT_STATUS_Write(jsonDDS);
		//hvac_obj->HVACFnMQTTWriteRequest(jsonDDS);
	}

	void TemperatureManager_MQTT(json obj){

		hvacDdsObj::hvacTemperatureObj tempobj;
		tempobj.temp=CORBA::string_dup(&std::string(obj["temp"])[0]);
		tempobj.zone=CORBA::string_dup(&std::string(obj["zone"])[0]);

		temperatureManager(tempobj);
	}

	void AutoacManager_MQTT(json obj){

		hvacDdsObj::hvacAutoAC autoacobj;
		autoacobj.status=(obj["status"]=="true") ? true : false;
		{
			std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
			hvac_cache.autoAcStatus=autoacobj.status;
		}

		hvacDdsObj::ListenerTypeStruct* lst=new hvacDdsObj::ListenerTypeStruct();
		lst->_d(hvacDdsObj::featureType::AUTOAC);
		lst->autoACObj(autoacobj);
		hvacDdsObj::hvacListenerObj hvac_response;
		hvac_response.messageId=CORBA::string_dup("autoac update");
		hvac_response.feature=hvacDdsObj::featureType::AUTOAC;
		hvac_response.featureObj=*lst;
		hvacUiPtr->HVACFn_HVACRESPONSE_Write(hvac_response);
		//hvac_obj->HVACFnResponseWriteRequest(hvac_response);
		std::free(lst);
	}

	void DefoggerManager_MQTT(json obj){
		hvacDdsObj::hvacDefogger defoggerobj;
		defoggerobj.status=(obj["status"]=="true") ? true : false;
		{
			std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
			hvac_cache.defoggerStatus=defoggerobj.status;	
		}

		hvacDdsObj::ListenerTypeStruct* lst=new hvacDdsObj::ListenerTypeStruct();
		lst->_d(hvacDdsObj::featureType::DEFOGGER);
		lst->defoggerObj(defoggerobj);
		hvacDdsObj::hvacListenerObj hvac_response;
		hvac_response.messageId=CORBA::string_dup("defogger update");
		hvac_response.feature=hvacDdsObj::featureType::DEFOGGER;
		hvac_response.featureObj=*lst;
		hvacUiPtr->HVACFn_HVACRESPONSE_Write(hvac_response);
		//hvac_obj->HVACFnResponseWriteRequest(hvac_response);
		std::free(lst);
	}

	void ClimateFlowControlManager_MQTT(json obj){
		hvacDdsObj::hvacClimateFlowControl cfcobj;
		cfcobj=(obj["enum"]=="low") ? hvacDdsObj::hvacClimateFlowControl::low : hvacDdsObj::hvacClimateFlowControl::high;
		hvac_cache.climateFlowControlObj=cfcobj;

		hvacDdsObj::ListenerTypeStruct* lst=new hvacDdsObj::ListenerTypeStruct();
		lst->_d(hvacDdsObj::featureType::CLIMATE_FLOW_CONTROL);
		lst->climateFlowControlObj(cfcobj);
		hvacDdsObj::hvacListenerObj hvac_response;
		hvac_response.messageId=CORBA::string_dup("climate flow control update");
		hvac_response.feature=hvacDdsObj::featureType::CLIMATE_FLOW_CONTROL;
		hvac_response.featureObj=*lst;
		hvacUiPtr->HVACFn_HVACRESPONSE_Write(hvac_response);
		//hvac_obj->HVACFnResponseWriteRequest(hvac_response);
		std::free(lst);
	}

	void FanSpeedManager_MQTT(json obj){
		hvacDdsObj::hvacFanSpeed fanSpeedObj;
		std::string enumVal=std::string(obj["enum"]);

		if(enumVal=="FAN_SPEED_1") fanSpeedObj=hvacDdsObj::hvacFanSpeed::FAN_SPEED_1;
		else if(enumVal=="FAN_SPEED_2") fanSpeedObj=hvacDdsObj::hvacFanSpeed::FAN_SPEED_2;
		else if(enumVal=="FAN_SPEED_3") fanSpeedObj=hvacDdsObj::hvacFanSpeed::FAN_SPEED_3;
		
		{
			std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
			hvac_cache.fanSpeedObj=fanSpeedObj;
		}

		hvacDdsObj::ListenerTypeStruct* lst=new hvacDdsObj::ListenerTypeStruct();
		lst->_d(hvacDdsObj::featureType::FAN_SPEED);
		lst->fanSpeedObj(fanSpeedObj);
		hvacDdsObj::hvacListenerObj hvac_response;
		hvac_response.messageId=CORBA::string_dup("fan speed update");
		hvac_response.feature=hvacDdsObj::featureType::FAN_SPEED;
		hvac_response.featureObj=*lst;
		hvacUiPtr->HVACFn_HVACRESPONSE_Write(hvac_response);
		//hvac_obj->HVACFnResponseWriteRequest(hvac_response);
		std::free(lst);
	}

	public:

	void initialize_cache(hvacStateMachine* hvacCachePtr){

		std::ifstream inStream;
		inStream.open("default.json");
		std::stringstream ssBuffer;
		ssBuffer<<inStream.rdbuf();
		json temporaryJsonHolder=json::parse(ssBuffer.str());
		hvacCachePtr->currentTemperature=temporaryJsonHolder["currentTemperature"];
		hvacCachePtr->zone=temporaryJsonHolder["zone"];//all
		hvacCachePtr->autoAcStatus=temporaryJsonHolder["autoAcStatus"];//false;
		hvacCachePtr->defoggerStatus=temporaryJsonHolder["defoggerStatus"]; //false;
		std::string climateFlowControlObj_json=temporaryJsonHolder["climateFlowControlObj"];
		hvacCachePtr->climateFlowControlObj=(climateFlowControlObj_json=="low") ? hvacDdsObj::hvacClimateFlowControl::low : hvacDdsObj::hvacClimateFlowControl::high;
		std::string fanSpeedObj_json=temporaryJsonHolder["fanSpeedObj"];

		if(fanSpeedObj_json=="FAN_SPEED_1") hvacCachePtr->fanSpeedObj=hvacDdsObj::hvacFanSpeed::FAN_SPEED_1;
		if(fanSpeedObj_json=="FAN_SPEED_2") hvacCachePtr->fanSpeedObj=hvacDdsObj::hvacFanSpeed::FAN_SPEED_2;
		if(fanSpeedObj_json=="FAN_SPEED_3") hvacCachePtr->fanSpeedObj=hvacDdsObj::hvacFanSpeed::FAN_SPEED_3;
			
	}

	void HVACREAD_Listener(hvacDdsObj::hvacReadReqObj obj){

		hvacDdsObj::hvacListenerObj tmtObj;
		hvacDdsObj::ListenerTypeStruct* lts=new hvacDdsObj::ListenerTypeStruct();
		hvacDdsObj::hvacTemperatureObj tempObj;
		hvacDdsObj::hvacAutoAC autoacobj;
		hvacDdsObj::hvacDefogger defoggerobj;
		hvacDdsObj::hvacClimateFlowControl climateobj;
		hvacDdsObj::hvacFanSpeed fanspeedobj;

		tmtObj.messageId="simulator read response";
		tmtObj.feature=obj.feature;
		
		lts->_d(obj.feature);

		switch(obj.feature){

			case hvacDdsObj::featureType::TEMPERATURE:
				{
					std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
					tempObj.temp=CORBA::string_dup(&std::to_string(hvac_cache.currentTemperature)[0]);
					tempObj.zone=CORBA::string_dup(&hvac_cache.zone[0]);
				}
				lts->temperatureObj(tempObj);
				break;
			case hvacDdsObj::featureType::AUTOAC:
				{
					std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
					autoacobj.status=hvac_cache.autoAcStatus;
				}
				lts->autoACObj(autoacobj);
				break;
			case hvacDdsObj::featureType::DEFOGGER:
				{
					std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
					defoggerobj.status=hvac_cache.defoggerStatus;
				}
				lts->defoggerObj(defoggerobj);
				break;
			case hvacDdsObj::featureType::CLIMATE_FLOW_CONTROL:
				{
					std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
					climateobj=hvac_cache.climateFlowControlObj;
				}
				lts->climateFlowControlObj(climateobj);
				break;
			case hvacDdsObj::featureType::FAN_SPEED:
				{
					std::lock_guard<std::mutex> lock_obj(hvacCache_lock);
					fanspeedobj=hvac_cache.fanSpeedObj;
				}
				lts->fanSpeedObj(fanspeedobj);
				break;
		}
		tmtObj.featureObj=*lts;
		hvacUiPtr->HVACFn_HVACRESPONSE_Write(tmtObj);
		printf("\n read request -> response sent \n");
	}

	void HVACWRITE_Listener(hvacDdsObj::hvacWriteReqObj obj){

		printf(" HVACWRITE_Listener reached");

		switch(obj.req){

			case hvacDdsObj::featureType::TEMPERATURE:
				temperatureManager(obj.featureObj.temperatureObj());
				break;
			case hvacDdsObj::featureType::AUTOAC:
				autoacManager(obj.featureObj.autoACObj());
				break;
			case hvacDdsObj::featureType::DEFOGGER:
				defoggerManager(obj.featureObj.defoggerObj());
				break;
			case hvacDdsObj::featureType::CLIMATE_FLOW_CONTROL:
				climateFlowControlManager(obj.featureObj.climateFlowControlObj());
				break;
			case hvacDdsObj::featureType::FAN_SPEED:
				fanSpeedManager(obj.featureObj.fanSpeedObj());
				break;
		}
	}

	void HVAC_MQTT_SET_STATUS_Listener(hvacDdsObj::DataType obj){

		std::string jsonString=std::string(obj.params);
		json hvacJsonMessage=json::parse(jsonString);
		std::cout<<"hvacJsonMessage"<<hvacJsonMessage.dump();

		if(hvacJsonMessage["1"]["req"]!="NA") TemperatureManager_MQTT(hvacJsonMessage["1"]["hvacTemperatureObj"]);
		if(hvacJsonMessage["2"]["req"]!="NA") AutoacManager_MQTT(hvacJsonMessage["2"]["hvacAutoAC"]);
		if(hvacJsonMessage["3"]["req"]!="NA") DefoggerManager_MQTT(hvacJsonMessage["3"]["hvacDefogger"]);
		if(hvacJsonMessage["4"]["req"]!="NA") ClimateFlowControlManager_MQTT(hvacJsonMessage["4"]["hvacClimateFlowControl"]);
		if(hvacJsonMessage["5"]["req"]!="NA") FanSpeedManager_MQTT(hvacJsonMessage["5"]["hvacFanSpeed"]);
	}

	void SystemNotification(SystemNotificationObj obj_struct){

		//do nothing
	}

	void SystemNotificationMQTT(SystemNotificationObj obj_struct){

		//do nothing
	}

	hvac_simulator(int domain_id,int argc,char** argv) : mqttMessage( {{"1",{
									                                        	{"messageId","message_temperature"},
									                                        	{"req","TEMPERATURE"},
									                                        	{"hvacTemperatureObj",{
									                                            	                    {"temp","17"},{"zone","all"}
									                                                	              }
									                                        	}
									                                       	}
									                                   },
									                                   {"2",{
									                                        	{"messageId","message_autoac"},
									                                        	{"req","AUTOAC"},
									                                        	{"hvacAutoAC",{
									                                        					{"status","true"}
									                                        				  }
									                                        	} 
									                                    	}
									                                    },
									                                   {"3",{
									                                        	{"messageId","message_defogger"},
									                                        	{"req","DEFOGGER"},
									                                        	{"hvacDefogger",{
									                                        						{"status","true"}
									                                        					}
									                                        	}
									                                    	}
									                                    },
									                                   {"4",{
									                                        	{"messageId","message_climate_flow_control"},
									                                        	{"req","CLIMATE_FLOW_CONTROL"}, 
									                                        	{"hvacClimateFlowControl",{
									                                        								{"enum","low"}
									                                        							  }
									                                        	}
									                                    	}
									                                    },
									                                   {"5",{
									                                        	{"messageId","message_fan_speed"},
									                                        	{"req","FAN_SPEED"},
									                                        	{"hvacFanSpeed",{
									                                        						{"enum","FAN_SPEED_1"}
									                                        					}
									                                        	}
									                                    	}
									                                	}}
																){
  		
  		initialize_cache(&hvac_cache);
  		this->isTemperatureThreadRunning=0;
  		hvacUiPtr=new ddsNode_hvacUI(domain_id,argc,argv);
  		hvacMqttPtr=new ddsNode_hvacMQTT(domain_id,argc,argv);
  		//hvac_obj=new ddsHVAC_SimLib(domain_id,argc,argv);

  		std::function<void (hvacDdsObj::hvacReadReqObj)> functor1(std::bind(&hvac_simulator::HVACREAD_Listener,this,std::placeholders::_1));
  		std::function<void (hvacDdsObj::hvacWriteReqObj)> functor2(std::bind(&hvac_simulator::HVACWRITE_Listener,this,std::placeholders::_1));
  		std::function<void (SystemNotificationObj)> functor3(std::bind(&hvac_simulator::SystemNotification,this,std::placeholders::_1));
  		
  		std::function<void (hvacDdsObj::DataType)> functor4(std::bind(&hvac_simulator::HVAC_MQTT_SET_STATUS_Listener,this,std::placeholders::_1));
  		std::function<void (SystemNotificationObj)> functor5(std::bind(&hvac_simulator::SystemNotificationMQTT,this,std::placeholders::_1));

  		//if(hvac_obj->HVACFnReadRequestListener(functor1)!=ddsHVAC_SimLib::OK) printf("read listener error");
  		//if(hvac_obj->HVACFnWriteRequestListener(functor2)!=ddsHVAC_SimLib::OK) printf("write listener error");
  		//if(hvac_obj->HVACFnSysNotification(functor3)!=ddsHVAC_SimLib::OK) printf("sys notification error");

		//if(hvac_obj->HVACFnMQTTListener(functor4)!=ddsHVAC_SimLib::OK) printf("MQTT listener error");
  		//if(hvac_obj->HVACFnSysNotification(functor5)!=ddsHVAC_SimLib::OK) printf("MQTT sys notification error");

  		hvacUiPtr->HVACFn_HVACREAD_Listener(functor1);
  		hvacUiPtr->HVACFn_HVACWRITE_Listener(functor2);
  		hvacUiPtr->HVACFn_SysNotification(functor3);

  		hvacMqttPtr->HVACFn_HVAC_MQTT_SET_STATUS_Listener(functor4);
  		hvacMqttPtr->HVACFn_SysNotification(functor5);

  		hvacUiPtr->activateNode();
  		hvacMqttPtr->activateNode();
	}

	~hvac_simulator(){
		delete hvacUiPtr;
		delete hvacMqttPtr;
	}

};

int main(int argc,char** argv){
	char *hvac_argv[3]={"hvac_simulator.cpp", "-DCPSConfigFile", "rtps.ini"};
	int hvac_argc=3;
	int domainId=42;
	hvac_simulator simObj(domainId,hvac_argc,hvac_argv);
	try{
		while(true){
			//simObj.send();
			//std::this_thread::sleep_for(std::chrono::seconds(1));
		}
	}
	catch(std::exception e){
		printf("\nthread terminated\n");
	}
}