INSTALL-

1. sudo apt-get install libcpprest-dev

BUILD-

1. mkdir bin (delete bin if it already exists)
2. cd copy2bin/default.json bin/default.json
3. cd bin
4. cmake ..
5. make -j4

RUN-

1. cd bin
2. ./restSimulator

TEST-
tested with postman with the following json-

{
    "1":{
        "messageId":"message_temperature",
        "req":"TEMPERATURE",
        "hvacTemperatureObj":{
            "temp":"17",
            "zone":"all"
        }
    },
    "2":{
        "messageId":"message_temperature",
        "req":"AUTOAC",
        "hvacAutoAC":{
            "status":"true"
        }
    },
    "3":{
        "messageId":"message_temperature",
        "req":"DEFOGGER",
        "hvacDefogger":{
            "status":"true"
        }
    },
    "4":{
        "messageId":"message_temperature",
        "req":"CLIMATE_FLOW_CONTROL",
        "hvacClimateFlowControl":{
            "enum":"low"
        }
    },
    "5":{
        "messageId":"message_temperature",
        "req":"FAN_SPEED",
        "hvacFanSpeed":{
            "enum":"FAN_SPEED_1"
        }
    }
}

